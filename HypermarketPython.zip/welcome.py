import tkinter as tk
from PIL import Image, ImageTk
from tkinter import messagebox
from main import main_page  # Assuming your main file is named main.py

valid_credentials = {
    "usama": "35404",
    "ayesha": "35187",
    "afaq": "37298",
    "rafeh": "37608",
    "salman": "35372",
    "ehtasham": "33815",
    # Add more username: password pairs as needed
}

def validate_login():
    username = username_entry.get()
    password = password_entry.get()

    if username in valid_credentials and valid_credentials[username] == password:
        add_button.destroy()  # Close the login window
        open_main_page()  # Open the main inventory management system
    else:
        messagebox.showerror("Invalid Credentials", "Please enter valid username and password")

def open_main_page():
    main_page()  # Open the main inventory management system

def on_enter(e):
    login_button.config(bg='cyan', fg='black')

def on_leave(e):
    login_button.config(bg='black', fg='cyan')

def on_click(e):
    login_button.config(bg='red', fg='white')
    login_button.after(300, lambda: login_button.config(bg='black', fg='cyan'))

def login_page():
    global add_button  # Access the global add_button variable
    add_button = tk.Tk()
    add_button.title("Login")

    # Load the image using PIL and resize
    image = Image.open("work_image.jpg")  # Replace with your image file path
    resized_image = image.resize((800, 500))
    bg_image = ImageTk.PhotoImage(resized_image)

    # Get the image dimensions
    image_width, image_height = resized_image.size

    # Create a canvas to place the background image
    canvas = tk.Canvas(add_button, width=image_width, height=image_height)
    canvas.pack(fill="both", expand=True)

    # Display the resized background image
    canvas.create_image(0, 0, image=bg_image, anchor="nw")

    # Welcome Label
    welcome_label = tk.Label(add_button, text="Welcome to the System", font=("Algerian", 18))
    welcome_label.place(x=280, y=40)

    # Username Label and Entry
    username_label = tk.Label(add_button, text="Username:")
    username_label.place(x=300, y=128)
    global username_entry  # Make entry field global
    username_entry = tk.Entry(add_button)
    username_entry.place(x=385, y=130)

    # Password Label and Entry
    password_label = tk.Label(add_button, text="Password:")
    password_label.place(x=300, y=180)
    global password_entry  # Make entry field global
    password_entry = tk.Entry(add_button, show="*")
    password_entry.place(x=385, y=181)

    global login_button  # Make button global
    login_button = tk.Button(add_button, text="Login", command=validate_login, bg='black', fg='cyan',
    relief=tk.FLAT, font=('Arial', 12))
    login_button.place(x=420, y=240)
    login_button.bind("<Enter>", on_enter)
    login_button.bind("<Leave>", on_leave)
    login_button.bind("<Button-1>", on_click)

    add_button.mainloop()

if __name__ == "__main__":
    login_page()
