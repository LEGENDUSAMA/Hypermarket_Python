import tkinter as tk
from PIL import Image, ImageTk
from tkinter import messagebox
from your_inventory_module import Inventory

def edit_product(product, inventory):
    inventory.edit_product(product)

def edit_product_gui(inventory, main_window):
    def edit_clicked():
        # Read input values from the GUI
        name = name_entry.get()
        new_price = float(price_entry.get())
        new_quantity = int(quantity_entry.get())
        new_location = location_entry.get()

        inventory.edit_product(name, new_price, new_quantity, new_location)
        messagebox.showinfo("Success", f"{name} details updated.")

    def go_back():
        add_window.destroy()  # Close the add window
        main_window.deiconify()  # Restore the main window

    add_window = tk.Toplevel(main_window)
    add_window.title("Edit Product")

    # Load the image using PIL and resize (adjust the path and size as needed)
    image = Image.open("work_image.jpg")  # Replace with your image file path
    resized_image = image.resize((800, 500))
    bg_image = ImageTk.PhotoImage(resized_image)

    # Get the image dimensions
    image_width, image_height = resized_image.size

    # Create a canvas to place the background image
    canvas = tk.Canvas(add_window, width=image_width, height=image_height)
    canvas.pack(fill="both", expand=True)

    # Display the resized background image
    canvas.create_image(0, 0, image=bg_image, anchor="nw")

    # Create GUI components for Editing a product
    tk.Label(add_window, text="Name:").place(x=250, y=50)
    tk.Label(add_window, text="New Price:").place(x=250, y=100)
    tk.Label(add_window, text="New Quantity:").place(x=250, y=150)
    tk.Label(add_window, text="New Location:").place(x=250, y=200)

    name_entry = tk.Entry(add_window)
    name_entry.place(x=350, y=50)
    price_entry = tk.Entry(add_window)
    price_entry.place(x=350, y=100)
    quantity_entry = tk.Entry(add_window)
    quantity_entry.place(x=350, y=150)
    location_entry = tk.Entry(add_window)
    location_entry.place(x=350, y=200)

    add_button = tk.Button(add_window, text="Click for Edit", command=edit_clicked)
    add_button.place(x=350, y=270)

    back_button = tk.Button(add_window, text="Back", command=go_back)
    back_button.place(x=250, y=270)

    main_window.withdraw()  # Hide the main window

    add_window.mainloop()

if __name__ == "__main__":
    main_window = tk.Tk()
    main_window.title("Main Window")
    inventory = Inventory()
    edit_product_gui(inventory, main_window)
