import tkinter as tk
from PIL import Image, ImageTk
from your_inventory_module import Inventory
from add_product import add_product_gui
from display_inventory import display_inventory_gui
from edit_product import edit_product_gui
from remove_product import remove_product_gui
from search_product import search_product_gui

def main_page():
    def open_add_product():
        add_product_gui(inventory, root)

    def open_edit_product():
        edit_product_gui(inventory, root)

    def open_display_product():
        display_inventory_gui(inventory, root)

    def open_remove_product():
        remove_product_gui(inventory, root)

    def open_search_product():
        search_product_gui(inventory, root)

    def logout(e=None):
        root.destroy()  # Close the inventory management system
        # Open the welcome.py script (assuming the file name is welcome.py)
        import welcome
        welcome.login_page()  # Assuming the welcome.py script has a function named login_page()

    def on_enter(e):
        logout_button.config(bg='cyan', fg='black')

    def on_leave(e):
        logout_button.config(bg='black', fg='cyan')

    def on_click(e):
        logout_button.config(bg='red', fg='white')
        logout_button.after(300, lambda: logout_button.config(bg='black', fg='cyan'))

    root = tk.Tk()
    root.title("Inventory Management")

    inventory = Inventory()

    # Load the image using PIL and resize (adjust the path and size as needed)
    image_path = "work_image.jpg"  # Replace with your image file path
    image = Image.open(image_path)
    desired_width = 800
    desired_height = 500
    resized_image = image.resize((desired_width, desired_height))
    bg_image = ImageTk.PhotoImage(resized_image)

    # Create a canvas to display the background image
    canvas = tk.Canvas(root, width=desired_width, height=desired_height)
    canvas.pack()

    # Display the resized background image
    canvas.create_image(0, 0, image=bg_image, anchor="nw")

    # Create buttons
    add_button = tk.Button(root, text="Add Product", command=open_add_product)
    add_button.place(relx=0.1, rely=0.2)

    edit_button = tk.Button(root, text="Edit Product", command=open_edit_product)
    edit_button.place(relx=0.1, rely=0.3)

    display_button = tk.Button(root, text="Display Product", command=open_display_product)
    display_button.place(relx=0.1, rely=0.4)

    search_button = tk.Button(root, text="Search Product", command=open_search_product)
    search_button.place(relx=0.1, rely=0.5)

    remove_button = tk.Button(root, text="Remove Product", command=open_remove_product)
    remove_button.place(relx=0.1, rely=0.6)


    # Log Out button
    global logout_button  # Make button global
    logout_button = tk.Button(root, text="Log Out", command=logout, bg='black', fg='cyan',
                              relief=tk.FLAT, font=('Arial', 14))
    logout_button.place(x=340, y=380)
    logout_button.bind("<Enter>", on_enter)
    logout_button.bind("<Leave>", on_leave)
    logout_button.bind("<Button-1>", on_click)

    root.mainloop()

if __name__ == "__main__":
    main_page()
