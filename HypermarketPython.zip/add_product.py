import tkinter as tk
from PIL import Image, ImageTk
from tkinter import messagebox
from your_inventory_module import Inventory, Product


def add_product(product, inventory):
    inventory.add_product(product)


def add_product_gui(inventory, main_window):
    def add_clicked():
        name = name_entry.get()
        price = price_entry.get()
        quantity = quantity_entry.get()
        location = location_entry.get()

        # Validate the input fields
        if not name or not price or not quantity or not location:
            messagebox.showerror("Error", "Please fill in all the fields.")
            return

        try:
            price = float(price)
            quantity = int(quantity)
        except ValueError:
            messagebox.showerror("Error", "Invalid price or quantity.")
            return

        new_product = Product(name, price, quantity, location)
        add_product(new_product, inventory)

        messagebox.showinfo("Success", f"{name} added to inventory.")
        add_window.destroy()  # Close the add window after adding the product
        main_window.deiconify()  # Restore the main window

    def go_back():
        add_window.destroy()  # Close the add window
        main_window.deiconify()  # Restore the main window

    add_window = tk.Toplevel(main_window)
    add_window.title("Add Product")

    # Load the image using PIL and resize
    image = Image.open("work_image.jpg")  # Replace with your image file path
    resized_image = image.resize((800, 500))
    bg_image = ImageTk.PhotoImage(resized_image)

    # Get the image dimensions
    image_width, image_height = resized_image.size

    # Create a canvas to place the background image
    canvas = tk.Canvas(add_window, width=image_width, height=image_height)
    canvas.pack(fill="both", expand=True)

    # Display the resized background image
    canvas.create_image(0, 0, image=bg_image, anchor="nw")

    # Create GUI components for adding a product
    tk.Label(add_window, text="Name:").place(x=250, y=50)
    tk.Label(add_window, text="Price:").place(x=250, y=100)
    tk.Label(add_window, text="Quantity:").place(x=250, y=150)
    tk.Label(add_window, text="Location:").place(x=250, y=200)

    name_entry = tk.Entry(add_window)
    name_entry.place(x=350, y=50)
    price_entry = tk.Entry(add_window)
    price_entry.place(x=350, y=100)
    quantity_entry = tk.Entry(add_window)
    quantity_entry.place(x=350, y=150)
    location_entry = tk.Entry(add_window)
    location_entry.place(x=350, y=200)

    add_button = tk.Button(add_window, text="Click for Add", command=add_clicked)
    add_button.place(x=350, y=270)

    back_button = tk.Button(add_window, text="Back", command=go_back)
    back_button.place(x=250, y=270)

    main_window.withdraw()  # Hide the main window

    add_window.mainloop()


if __name__ == "__main__":
    main_window = tk.Tk()
    main_window.title("Main Window")

    inventory = Inventory()

    add_product_gui(inventory, main_window)