import sqlite3

class Product:
    def __init__(self, name, price, quantity, location):
        self.name = name
        self.price = price
        self.quantity = quantity
        self.location = location

class Inventory:
    def __init__(self):
        self.conn = sqlite3.connect('inventory.db')
        self.cursor = self.conn.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                price REAL,
                quantity INTEGER,
                location TEXT
            )
        ''')
        self.conn.commit()
    
    def edit_product(self, product_name, new_price, new_quantity, new_location):
        self.cursor.execute('''
            UPDATE products
            SET price = ?, quantity = ?, location = ?
            WHERE name = ?
        ''', (new_price, new_quantity, new_location, product_name))
        self.conn.commit()
        print(f"{product_name} details updated.")
    
    def remove_product(self, product_name):
        self.cursor.execute('DELETE FROM products WHERE name = ?', (product_name,))
        self.conn.commit()

    def add_product(self, product):
        self.cursor.execute('''
            INSERT INTO products (name, price, quantity, location)
            VALUES (?, ?, ?, ?)
        ''', (product.name, product.price, product.quantity, product.location))
        self.conn.commit()
        print(f"{product.name} added to inventory.")

    def search_product(self, product_name):
        self.cursor.execute('SELECT * FROM products WHERE name = ?', (product_name,))
        result = self.cursor.fetchone()
        if result:
            return Product(result[1], result[2], result[3], result[4])
        else:
            return None

if __name__ == "__main__":
    inventory = Inventory()
    inventory.remove_product("Product Name to Remove")
