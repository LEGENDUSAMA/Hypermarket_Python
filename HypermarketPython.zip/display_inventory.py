import tkinter as tk
from PIL import Image, ImageTk
import sqlite3

class Inventory:
    def __init__(self):
        self.conn = sqlite3.connect('inventory.db')
        self.cursor = self.conn.cursor()

    def fetch_inventory_data(self):
        self.cursor.execute('SELECT * FROM products')
        return self.cursor.fetchall()

def display_inventory_gui(inventory, main_window):
    inventory = Inventory()
    data = inventory.fetch_inventory_data()

    def go_back():
        add_window.destroy()  # Close the add window
        main_window.deiconify()  # Restore the main window

    def on_scroll(*args):
        inventory_display.yview(*args)

    add_window = tk.Toplevel(main_window)
    add_window.title("Display Inventory")

    # Load the image using PIL and resize
    image = Image.open("work_image.jpg")  # Replace with your image file path
    resized_image = image.resize((800, 500))
    bg_image = ImageTk.PhotoImage(resized_image)

    # Get the image dimensions
    image_width, image_height = resized_image.size

    # Create a canvas to place the background image
    canvas = tk.Canvas(add_window, width=image_width, height=image_height)
    canvas.pack(fill="both", expand=True)

    # Display the resized background image
    canvas.create_image(0, 0, image=bg_image, anchor="nw")

    inventory_frame = tk.Frame(add_window)
    inventory_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

    scrollbar = tk.Scrollbar(inventory_frame)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    inventory_display = tk.Text(inventory_frame, height=14, width=80, yscrollcommand=scrollbar.set)
    inventory_display.pack(side=tk.LEFT, fill=tk.BOTH)
    scrollbar.config(command=inventory_display.yview)
    inventory_display.bind('<Configure>', on_scroll)

    if not data:
        inventory_display.insert(tk.END, "Inventory is empty.")
    else:
        for product in data:
            inventory_display.insert(tk.END, f"Name: {product[1]}, Price: ${product[2]}, Quantity: {product[3]}, Location: {product[4]}\n")

    back_button = tk.Button(add_window, text="Back", command=go_back)
    back_button.place(x=380, y=400)

    main_window.withdraw()  # Hide the main window

    add_window.mainloop()

if __name__ == "__main__":
    main_window = tk.Tk()
    main_window.title("Main Window")

    inventory = Inventory()

    display_inventory_gui(inventory, main_window)
