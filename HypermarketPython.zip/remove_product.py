import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
from your_inventory_module import Inventory

def remove_product(product, inventory):
    inventory.remove_product(product)

def remove_product_gui(inventory, main_window):
    def remove_clicked():
        product_name = name_entry.get()
        inventory.remove_product(product_name)
        messagebox.showinfo("Success", f"{product_name} removed from inventory.")

    def go_back():
        add_window.destroy()  # Close the add window
        main_window.deiconify()  # Restore the main window

    add_window = tk.Toplevel(main_window)
    add_window.title("Remove Product")

   # Load the image using PIL and resize
    image = Image.open("work_image.jpg")  # Replace with your image file path
    resized_image = image.resize((800, 500))
    bg_image = ImageTk.PhotoImage(resized_image)

    # Get the image dimensions
    image_width, image_height = resized_image.size

    # Create a canvas to place the background image
    canvas = tk.Canvas(add_window, width=image_width, height=image_height)
    canvas.pack(fill="both", expand=True)

    # Display the resized background image
    canvas.create_image(0, 0, image=bg_image, anchor="nw")

    # Create GUI components for removing a product with specific positions
    tk.Label(add_window, text="Name:").place(x=250, y=150)
    
    name_entry = tk.Entry(add_window)
    name_entry.place(x=350, y=150)

    remove_button = tk.Button(add_window, text="Remove", command=remove_clicked)
    remove_button.place(x=350, y=220)

    back_button = tk.Button(add_window, text="Back", command=go_back)
    back_button.place(x=250, y=220)

    main_window.withdraw()  # Hide the main window

    add_window.mainloop()

if __name__ == "__main__":
    main_window = tk.Tk()
    main_window.title("Main Window")

    inventory = Inventory()

    remove_product_gui(inventory, main_window)
